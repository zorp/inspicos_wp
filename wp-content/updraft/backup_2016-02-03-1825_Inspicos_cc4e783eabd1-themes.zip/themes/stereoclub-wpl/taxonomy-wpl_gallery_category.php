<?php
/**
 * The default Custom Post Gallery Archive
 *
 * @package WordPress
 * @subpackage StereoClub
 * @since StereoClub 1.0.0
 */
?>

<?php include_once 'archive-post_gallery.php'; ?>