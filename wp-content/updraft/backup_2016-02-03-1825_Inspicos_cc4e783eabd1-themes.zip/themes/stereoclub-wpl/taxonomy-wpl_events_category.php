<?php
/**
 * The default Custom Post Events Archive
 *
 * @package WordPress
 * @subpackage StereoClub
 * @since StereoClub 1.0.0
 */
?>

<?php include_once 'archive-post_events.php'; ?>