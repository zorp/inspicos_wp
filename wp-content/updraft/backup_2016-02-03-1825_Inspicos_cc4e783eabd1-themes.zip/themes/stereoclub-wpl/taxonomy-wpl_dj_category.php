<?php
/**
 * The default Custom Post DJ Archive
 *
 * @package WordPress
 * @subpackage StereoClub
 * @since StereoClub 1.0.0
 */
?>

<?php include_once 'archive-post_dj.php'; ?>